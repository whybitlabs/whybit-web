# Lun-E firmware

Lun-E RC can be driven from two places:

- **Connect**, the thumbstick controller, over ESP-NOW. It has to be paired first.
- **The phone app**, a web page that talks to the rover over Bluetooth LE.

Both can be on at the same time. Whoever moves their stick first takes control. The other one can take over once the first stick has been centred for 0.3 s. If the driving side goes quiet for 0.3 s, the motors stop.

```
common/lune_protocol.h   packet formats + BLE UUIDs (shared by both firmwares and the app)
rover/                   Lun-E RC firmware   (PlatformIO, ESP32-C3-MINI-1-H4)
glyph/                   Lun-E Glyph firmware (PlatformIO, Glyph ESP32-S3, TB6612FNG; advertises as Lun-E Glyph-XXXX)
connect/                 Connect firmware    (PlatformIO, Glyph C3)
app/index.html           phone app (Web Bluetooth), a single file
```

## Build and flash

Both projects use **pioarduino**, the community fork that brings Arduino-ESP32 core 3.x to PlatformIO. The URL is already in each `platformio.ini`. The stock PlatformIO `espressif32` platform is still on core 2.x and will not build these projects.

```
cd rover   && pio run -t upload && pio device monitor
cd connect && pio run -t upload && pio device monitor
```

- **Rover, first flash of a blank board:** short JP1 (BOOT, GPIO9) while you plug in USB. Flash, then remove JP1. After that, flashing over USB works directly.
- **Connect:** if the upload can't connect, hold BOOT while you plug it in.
- The libraries download automatically: NimBLE-Arduino 2.x and U8g2.

## Flash from the browser (whybit.in/flash)

Anyone can flash the newest firmware without installing anything: open **https://whybit.in/flash/** in Chrome or Edge on a computer, plug the board in with USB-C, pick Lun-E RC / Lun-E Glyph / Connect and press flash. It uses ESP Web Tools (Web Serial), self-hosted on the site.

- Leave **Erase device** unticked to keep the rover's number, pairing, motor direction and trim.
- Blank Lun-E RC board: short JP1 while plugging in. Glyph boards: hold BOOT while plugging in.
- Linux: `sudo usermod -aG dialout $USER`, then log out and in.

**Publishing a new version** (on your laptop):

```
tools/publish-firmware.sh            # builds rover, glyph, connect → ~/whybit-web/flash/firmware/
```

then commit and push whybit-web. The script copies bootloader / partitions / boot_app0 / firmware .bin for each board and writes a `manifest.json` with a date version. It deliberately does **not** use `firmware.factory.bin`: that merged image fills the NVS area with 0xFF and would wipe every rover's settings.

## Before first drive

Check these on the bench with the treads off the ground.

1. **Motor direction — from the app, per rover, no reflashing.** Lift the rover, connect the app, open **Setup → motor direction**:
   - **Test left** runs the left tread forward for a moment. If the *other* tread moved, tap **Swap left ↔ right**. If it rolled backwards, tap **Reverse left**.
   - Then **Test right** and, if needed, **Reverse right**.
   - The setting is saved on that rover. `MOTOR_A_IS_LEFT`, `MOTOR_LEFT_INVERT` and `MOTOR_RIGHT_INVERT` in `config.h` are only the default for rovers that were never set up.
2. **Connect joystick pins** (`connect/src/config.h`). The defaults are VRx = GPIO0, VRy = GPIO1, SW = GPIO3, and the OLED on SDA 4 / SCL 5 (the Glyph's I2C). Change them to match your wiring. The X and Y pins must be GPIO0–4 (ADC1). SW must be GPIO0–5 so it can wake the controller. Then use `JOY_SWAP_XY` and the `JOY_INVERT_*` flags until the screen's stick dot moves the same way as your thumb.
3. **OLED orientation.** If the eyes show upside down, set `OLED_ROTATION 2`.
4. **N20 dead band.** If small stick moves hum without turning, raise `MOTOR_MIN_DUTY` (default 28 %).

## Pairing Connect with the rover

1. **Hold Connect right next to the rover** (a few cm). Rovers only answer a Connect that is close, so this works on a table full of rovers.
2. A new rover shows **PAIR ME** and is ready. A rover that was paired before needs a **triple-click on its button** first (30 s window). The app's Setup → *Pair a Connect* does the same.
3. On Connect, pairing starts by itself on first use. Otherwise, hold the stick button for 3 s, or hold it while powering on.
4. If several rovers answer, Connect picks the closest. Only that rover stores the pairing; the others forget it after 3 s.
5. The rover shows its number big, then **PAIRED!**. Connect shows **PAIRED!** and the rover's name in its header. Both remember the pairing across power-off.

If pairing never finishes, hold them closer, or lower `PAIR_RSSI_MIN` in `rover/src/config.h` (default −60 dBm).

## Lots of rovers in one room

No stickers needed — every rover can show who it is on its own screen. **Double-click its button** and its number (or, before it has one, the end of its MAC like `A3F1`) shows big on the OLED for 3 s.

Numbers are easier to read out than MAC endings, so give every rover a number once:

1. Switch on **one** rover and connect the app. Before it has a number it is called `Lun-E RC-A3F1` (or `Lun-E Glyph-A3F1`) — the end of its MAC.
2. Setup → **rover number** → type e.g. `7` → *Set number*. The rover shows `07` and restarts as **Lun-E 07**.
3. Reconnect. From now on the Bluetooth list, the app header and Connect's screen all say **Lun-E 07**.

Ways to tell which physical rover is which:

| | Does |
|---|---|
| Connect the app | the rover shows its number big for 2 s |
| App → **Find me** | number on the OLED for 3 s + headlights blink + a little left-right wiggle |
| **Double-click** the rover's button | its number big on the OLED for 3 s |
| Pair a Connect | the rover shows its number; Connect's header shows `Lun-E 07` |

## Controls

| | Rover button (GPIO5) | Connect | App |
|---|---|---|---|
| Eye expression | click (next) | BOOT click (next) | emoji row |
| Speed limit | — | stick double-click (40 / 70 / 100 %) | slider |
| Pair | triple-click | hold stick 3 s | Setup → Pair a Connect |
| Show number (who am I) | double-click | — | Find me (also blinks + wiggles) |
| Rover number | — | — | Setup → rover number |
| Sleep | hold 1.5 s (eyes fall asleep), then release | hold BOOT 1.5 s | Setup → Sleep (tap twice) |
| Wake | press button | stick click | — |
| Steering trim | — | — | Setup → trim slider (saved on the rover) |
| Motor direction | — | — | Setup → test left / right, reverse left / right, swap (saved on the rover) |
| Headlights | — | stick click: off → 33 → 66 → 100 % → off | 💡 button (on/off), brightness slider, `L` key |

Headlights are always **off** after the rover wakes up. The app slider sets the brightness and switches them on. The last brightness is remembered for the on/off button. On top of that they blink 3 times when a Connect pairs, twice when the Connect or app connects, flash once when a link is lost, and alternate left/right while the pairing window is open.

Auto-sleep:

- **Rover:** after 5 min with no Connect, no phone connected and no driving.
- **Connect:** after 3 min without touching the stick.

## Phone app

Web Bluetooth only works over **https**. Two ways to run the app:

- **Hosted:** open **https://whybit.in/drive/** in **Chrome on Android**. Desktop Chrome and Edge work too, with W A S D / arrow keys. `app/index.html` here is the same app as a standalone file.
- **Test locally:** run `python3 -m http.server` in `app/` and open `http://localhost:8000`. Browsers allow Bluetooth on localhost.

On **iPhone**, Safari has no Web Bluetooth. Open the page in the free **Bluefy** browser instead.

The rover advertises as `Lun-E 07` once numbered, or `Lun-E RC-A3F1` / `Lun-E Glyph-A3F1` (end of its MAC address) before that.

## Protocol summary

ESP-NOW runs on Wi-Fi channel 1. Neither board joins a Wi-Fi network. Every packet starts with `'L','E', version, type, seq`.

| Packet | Direction | Rate | Payload |
|---|---|---|---|
| PAIR_REQ | Connect → broadcast | 3 Hz while pairing | name |
| PAIR_ACK | rover → Connect | once | name, number |
| CONTROL | Connect → rover | 50 Hz moving, 10 Hz centred | x, y, maxSpeed, moodSeq, lightsSeq |
| TELEMETRY | rover → Connect | 5 Hz | flags, source, mood, L/R output, RSSI, lights %, number |

Button presses travel as counters (`moodSeq`, `lightsSeq`). A lost packet can't drop or repeat a press. Protocol version 4 (rover numbers), so flash every rover and Connect together.

BLE service `6e4c0001-…`:

- **DRIVE**: write without response. `int8 x, int8 y, uint8 maxSpeed`, sent at 20 Hz.
- **CMD**: write. `cmd, arg` — lights (0 off, 1–100 %, −1 toggle, −2 cycle), mood, trim, pair, sleep, set number (6), find me (7), motor wiring (8, bits: 1 = channel A is left, 2 = reverse left, 4 = reverse right), motor test (9, arg 1 left / 2 right).
- **STATUS**: notify at 5 Hz. 13 bytes, laid out in `LuneBleStatus` (byte 10 = headlight %, byte 11 = rover number, byte 12 = motor wiring bits). The motor commands are Bluetooth-only, so Connect does not need reflashing for them.
