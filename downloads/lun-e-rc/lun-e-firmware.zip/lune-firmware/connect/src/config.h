// Connect — pins and tuning. CHECK THE JOYSTICK PINS against your wiring.
#pragma once
#include <Arduino.h>

// ---- Pins (Glyph C3) -------------------------------------------------------
// Joystick axes must be on ADC1 pins (GPIO0–4 on the ESP32-C3).
#define PIN_JOY_X      0     // thumbstick VRx
#define PIN_JOY_Y      1     // thumbstick VRy
#define PIN_JOY_SW     3     // thumbstick push (active LOW). Must be GPIO0–5 to wake from sleep.
#define PIN_BOOT_BTN   9     // Glyph's BOOT button, used as a second button after boot
#define PIN_I2C_SDA    4     // Glyph default I2C / GLINK
#define PIN_I2C_SCL    5
#define OLED_ADDR      0x3C
#define PIN_BATT_SENSE -1    // ADC pin with a 1:2 divider from the battery, or -1 for none
#define BATT_DIVIDER   2.0f

// ---- Joystick orientation --------------------------------------------------
// Push the stick forward: the screen's Y bar must go up. Push right: X goes right.
#define JOY_SWAP_XY    0
#define JOY_INVERT_X   0
#define JOY_INVERT_Y   0
#define JOY_DEADZONE   8     // % around centre treated as 0
#define JOY_EXPO       35    // % — softens the centre for fine control (0 = linear)

// ---- Radio -----------------------------------------------------------------
#define SEND_ACTIVE_MS 20    // 50 Hz while the stick is moved
#define SEND_IDLE_MS   100   // 10 Hz heartbeat while centred (rover failsafe is 300 ms)
#define LINK_LOST_MS   1000  // no telemetry for this long -> "searching"
#define PAIR_REQ_MS    300

// ---- Buttons / power -------------------------------------------------------
#define PAIR_HOLD_MS   3000           // hold the stick button this long -> pairing
#define SLEEP_HOLD_MS  1500           // hold BOOT this long -> sleep
#define AUTO_SLEEP_MS  (3UL * 60UL * 1000UL)  // no stick movement

// Speed modes cycled by double-clicking the stick (percent of full speed).
static const uint8_t SPEED_MODES[] = {40, 70, 100};
#define DEFAULT_SPEED_MODE 1

// ---- Display ---------------------------------------------------------------
// 0 = normal, 2 = rotated 180°.
#define OLED_ROTATION  0
