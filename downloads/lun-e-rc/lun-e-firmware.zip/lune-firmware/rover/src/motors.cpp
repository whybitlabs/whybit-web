#include "motors.h"
#include "config.h"

namespace {
const uint32_t PWM_MAX = (1u << MOTOR_PWM_BITS) - 1;

struct Channel {
  uint8_t in1, in2;
  bool invert;
  float out = 0;  // applied, -100..100
};

#if MOTOR_A_IS_LEFT
Channel chL{PIN_AIN1, PIN_AIN2, MOTOR_LEFT_INVERT};
Channel chR{PIN_BIN1, PIN_BIN2, MOTOR_RIGHT_INVERT};
#else
Channel chL{PIN_BIN1, PIN_BIN2, MOTOR_LEFT_INVERT};
Channel chR{PIN_AIN1, PIN_AIN2, MOTOR_RIGHT_INVERT};
#endif

float targetL = 0, targetR = 0;
uint32_t lastUpdateUs = 0;
uint32_t lastNonZeroMs = 0;
bool driverAwake = false;

void setDriverAwake(bool awake) {
  if (awake == driverAwake) return;
  driverAwake = awake;
  digitalWrite(PIN_MOT_SLEEP, awake ? HIGH : LOW);
  if (awake) delayMicroseconds(1000);  // DRV8833 tWAKE max 1 ms
}

// Drive one H-bridge. pct: -100..100, already ramped.
void writeChannel(const Channel &c, float pct) {
  if (c.invert) pct = -pct;
  float mag = fabsf(pct);
  if (mag < 0.5f) {  // coast
    ledcWrite(c.in1, 0);
    ledcWrite(c.in2, 0);
    return;
  }
  // Map 1..100 % into MOTOR_MIN_DUTY..100 % so small stick moves still turn the N20.
  float duty = MOTOR_MIN_DUTY + (100.0f - MOTOR_MIN_DUTY) * (mag / 100.0f);
  uint32_t on = (uint32_t)(duty * PWM_MAX / 100.0f);
  if (on > PWM_MAX) on = PWM_MAX;
#if MOTOR_SLOW_DECAY
  // DRV8833 slow decay: one input held high, the other PWM'd with inverted duty.
  uint32_t off = PWM_MAX - on;
  if (pct > 0) { ledcWrite(c.in1, PWM_MAX); ledcWrite(c.in2, off); }
  else         { ledcWrite(c.in1, off);     ledcWrite(c.in2, PWM_MAX); }
#else
  // Fast decay: one input PWM, the other low.
  if (pct > 0) { ledcWrite(c.in1, on); ledcWrite(c.in2, 0); }
  else         { ledcWrite(c.in1, 0);  ledcWrite(c.in2, on); }
#endif
}

float approach(float cur, float target, float step) {
  if (target > cur) return min(target, cur + step);
  return max(target, cur - step);
}
}  // namespace

namespace Motors {

void begin() {
  pinMode(PIN_MOT_SLEEP, OUTPUT);
  digitalWrite(PIN_MOT_SLEEP, LOW);
  driverAwake = false;
  const uint8_t pins[4] = {PIN_AIN1, PIN_AIN2, PIN_BIN1, PIN_BIN2};
  for (uint8_t p : pins) {
    ledcAttach(p, MOTOR_PWM_FREQ, MOTOR_PWM_BITS);
    ledcWrite(p, 0);
  }
  lastUpdateUs = micros();
}

void setTarget(int left, int right) {
  targetL = constrain(left, -100, 100);
  targetR = constrain(right, -100, 100);
}

void update() {
  uint32_t now = micros();
  float dt = (now - lastUpdateUs) / 1e6f;
  lastUpdateUs = now;
  if (dt > 0.1f) dt = 0.1f;
  float step = MOTOR_SLEW_PER_S * dt;

  // Reversing direction: pass through zero first (ramp handles it naturally).
  chL.out = approach(chL.out, targetL, step);
  chR.out = approach(chR.out, targetR, step);

  bool moving = fabsf(chL.out) >= 0.5f || fabsf(chR.out) >= 0.5f;
  uint32_t ms = millis();
  if (moving) {
    lastNonZeroMs = ms;
    setDriverAwake(true);
  } else if (driverAwake && ms - lastNonZeroMs > MOTOR_IDLE_SLEEP_MS) {
    setDriverAwake(false);
  }
  writeChannel(chL, chL.out);
  writeChannel(chR, chR.out);
}

void stopNow() {
  targetL = targetR = 0;
  chL.out = chR.out = 0;
  writeChannel(chL, 0);
  writeChannel(chR, 0);
  setDriverAwake(false);
}

int left() { return (int)lroundf(chL.out); }
int right() { return (int)lroundf(chR.out); }

}  // namespace Motors
