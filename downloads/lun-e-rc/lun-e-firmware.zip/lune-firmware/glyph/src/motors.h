#pragma once
#include <Arduino.h>

namespace Motors {
void begin();
// Set the target tread speeds, -100..100 %. Output ramps towards it.
void setTarget(int left, int right);
// Call often (every loop). Applies ramping, dead band and STBY control.
void update();
// Immediate stop and driver sleep (failsafe / deep sleep).
void stopNow();
// Motor wiring, changeable at run time (saved per rover by main.cpp):
#define MOTOR_WIRING_A_IS_LEFT    0x01  // driver channel A drives the left tread
#define MOTOR_WIRING_INVERT_LEFT  0x02  // left tread spins backwards -> flip it
#define MOTOR_WIRING_INVERT_RIGHT 0x04  // right tread spins backwards -> flip it
#define MOTOR_WIRING_MASK         0x07
uint8_t defaultWiring();  // from config.h (MOTOR_A_IS_LEFT / MOTOR_*_INVERT)
void setWiring(uint8_t bits);
uint8_t wiring();
int left();   // currently applied output, -100..100
int right();
}  // namespace Motors
