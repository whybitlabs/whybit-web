#pragma once
#include <Arduino.h>

// Animated eyes on the 0.96" SSD1306 OLED (J5). Runs in its own FreeRTOS task,
// so drawing never delays motor control. Safe no-op if no OLED is fitted.
namespace Eyes {
bool begin();                         // returns false if no OLED answers on I2C
bool present();
void setMood(uint8_t mood);           // LuneMood
uint8_t mood();
void nextMood();
// Where the eyes look: -100..100 each. Pass driving input; idle -> wander.
void lookAt(int x, int y, bool active);
// Short caption under the eyes, e.g. "PAIRED". Shown for ms.
void say(const char *text, uint32_t ms = 1200);
// Close the eyes, turn the panel off. Blocks up to ~600 ms.
void shutdown();
}  // namespace Eyes
