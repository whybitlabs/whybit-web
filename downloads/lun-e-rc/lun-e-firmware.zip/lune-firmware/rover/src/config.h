// Lun-E RC — board pins and tuning. Pins match schematic v1.5.
#pragma once
#include <Arduino.h>

// ---- Pins (ESP32-C3-MINI-1) ------------------------------------------------
#define PIN_AIN1        4    // DRV8833 motor A
#define PIN_AIN2        0
#define PIN_BIN1        6    // DRV8833 motor B
#define PIN_BIN2        7
#define PIN_MOT_SLEEP   10   // DRV8833 nSLEEP, HIGH = motors enabled
#define PIN_HEADLIGHT_L 1    // D2 via R11 47R from 3V3, ACTIVE LOW (pin LOW = lit)
#define PIN_HEADLIGHT_R 20   // D3 via R12 47R from 3V3, ACTIVE LOW. Also U0RXD:
                             // keep UART0 unused (USB CDC is the serial port).
#define PIN_BUTTON      5    // user button, active LOW, deep-sleep wake
#define PIN_I2C_SDA     8    // OLED header J5
#define PIN_I2C_SCL     2
#define OLED_ADDR       0x3C

// ---- Motor wiring --------------------------------------------------------
// Which DRV8833 channel drives which tread, and whether it spins backwards.
// Test once on the bench: push the stick forward — both treads must drive
// forward. Fix with these flags — or per rover, without reflashing, in the
// app: Setup → motor direction (saved on the rover; overrides these defaults).
// Bench-tested on Lun-E RC (2026-10-26): channel B drives the left tread and
// spins it backwards; channel A drives the right tread the right way round.
#define MOTOR_A_IS_LEFT   0
#define MOTOR_LEFT_INVERT  1
#define MOTOR_RIGHT_INVERT 0

// ---- Motor tuning ----------------------------------------------------------
#define MOTOR_PWM_FREQ     20000  // Hz, above hearing
#define MOTOR_PWM_BITS     10
#define MOTOR_SLOW_DECAY   1      // 1 = brake between pulses (better low-speed torque)
#define MOTOR_MIN_DUTY     28     // % — N20 dead band; smallest non-zero command maps here
#define MOTOR_SLEW_PER_S   400    // % per second — limits current spikes on the 300 mAh cell
#define MOTOR_IDLE_SLEEP_MS 1500  // drop nSLEEP after this long at zero output
#define TURN_GAIN          70     // % — how strongly the stick's X axis turns
#define INPUT_DEADZONE     6      // % — stick values below this are treated as 0

// ---- Control / safety ------------------------------------------------------
#define FAILSAFE_MS        300    // stop if the active source goes quiet this long
#define HANDOVER_IDLE_MS   300    // other source may take over after the owner is neutral this long
#define CONNECT_LINK_MS    1000   // Connect counts as "linked" if heard within this
#define PAIRING_WINDOW_MS  30000
// Pairing in a crowd: only answer a Connect held close to this rover. Raise
// towards -50 if two neighbours both answer; lower towards -70 if pairing fails.
#define PAIR_RSSI_MIN      -60    // dBm
#define PAIR_CANDIDATE_MS  3000   // forget an answered Connect that picked another rover
#define IDENTIFY_MS        3000   // how long "find me" shows the number
#define IDENTIFY_WIGGLE_MS 700    // little left-right shimmy when identified (0 = off)
#define MOTOR_TEST_MS      900    // app Setup → test left / test right: run one tread this long
#define MOTOR_TEST_PCT     55     // ...at this speed, forward
#define TELEMETRY_MS       200    // rover -> Connect / app status rate

// ---- Power -----------------------------------------------------------------
#define AUTO_SLEEP_MS      (5UL * 60UL * 1000UL)  // idle with no Connect and no phone
#define BUTTON_SLEEP_MS    1500   // hold button this long, release -> deep sleep

// ---- Headlights ------------------------------------------------------------
// OFF after every wake-up. Connect: stick click cycles off -> 33 -> 66 -> 100 %.
// App: lights button (toggle) + brightness slider.
// Cues on top of the setting: 3 fast blinks = paired, 2 = Connect/app connected,
// long flash = link lost, 1 short = new eye expression / trim; alternating
// left/right while the pairing window is open; fade out with the sleep animation.
// Set HEADLIGHTS_ENABLED to 0 on boards built without D2/D3/R11/R12.
#define HEADLIGHTS_ENABLED        1
#define HEADLIGHT_DEFAULT_PCT     66     // first "toggle on" brightness until one is chosen
#define HEADLIGHT_CYCLE_STEPS     {33, 66, 100}   // Connect stick-click steps, %
#define HEADLIGHT_SAVE_DELAY_MS   2000   // brightness saved to flash this long after the last change
#define HEADLIGHT_PAIRING_HALF_MS 250    // pairing blink: each side on this long
#define HEADLIGHT_SLEEP_FADE_MS   1800   // sleep: fade-out time (sleep animation is 2.4 s)
#define HEADLIGHT_SMOOTH_MS       200    // brightness changes ease over this long
#define HEADLIGHT_TASK_HZ         100
#define HEADLIGHT_PWM_FREQ        MOTOR_PWM_FREQ   // shares the motor timer (C3: 4 motor + 2 light channels = all 6)
#define HEADLIGHT_PWM_BITS        MOTOR_PWM_BITS

// ---- Display ---------------------------------------------------------------
// 0 = normal, 2 = rotated 180° (if the eyes appear upside down).
#define OLED_ROTATION      0
#define EYES_FPS           30
