// Connect — ESP-NOW controller for Lun-E RC (Glyph C3 + thumbstick + 0.96" OLED)
//
// Stick:        drive (arcade: Y = throttle, X = turn)
// Stick double-click: speed mode 40 / 70 / 100 %
// Stick hold 3 s:     pair with a rover (double-click the rover's button too)
// BOOT click:   next eye expression on the rover
// BOOT hold 1.5 s:    sleep (wake with a stick click). Also sleeps after 3 min idle.

#include <Arduino.h>
#include <Preferences.h>
#include <U8g2lib.h>
#include <WiFi.h>
#include <Wire.h>
#include <driver/gpio.h>
#include <esp_now.h>
#include <esp_sleep.h>
#include <esp_wifi.h>
#include <soc/soc_caps.h>
#include "config.h"
#include "lune_protocol.h"

#if OLED_ROTATION == 2
#define U8_ROT U8G2_R2
#else
#define U8_ROT U8G2_R0
#endif
static U8G2_SSD1306_128X64_NONAME_F_HW_I2C oled(U8_ROT, U8X8_PIN_NONE, PIN_I2C_SCL, PIN_I2C_SDA);
static bool hasOled = false;

static const uint8_t BROADCAST[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
static const char *MOOD_NAMES[LUNE_MOOD_COUNT] = {"normal", "happy", "sad", "angry", "sleepy", "wow"};

// ---- State -----------------------------------------------------------------
enum Mode : uint8_t { MODE_PAIRING, MODE_DRIVE, MODE_SLEEPING };
static volatile Mode mode = MODE_DRIVE;
static uint8_t roverMac[6];
static bool hasRover = false;
static char roverName[13] = "";

static int centerX = 2048, centerY = 2048;
static volatile int8_t stickX = 0, stickY = 0;
static uint8_t speedMode = DEFAULT_SPEED_MODE;
static uint8_t moodSeq = 0, txSeq = 0;
static uint32_t lastMoveMs = 0;

// Written in the Wi-Fi task
static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
static LuneTelemetry telem = {};
static volatile uint32_t telemMs = 0;
static volatile bool ackPending = false;
static uint8_t ackMac[6];
static char ackName[13];

// Short message on screen
static char toast[20] = "";
static uint32_t toastUntil = 0;
static void showToast(const char *t, uint32_t ms = 1200) {
  portENTER_CRITICAL(&mux);
  strncpy(toast, t, sizeof(toast) - 1);
  toastUntil = millis() + ms;
  portEXIT_CRITICAL(&mux);
}

// ---------------------------------------------------------------------------
// Buttons
// ---------------------------------------------------------------------------
struct Button {
  enum Event { NONE, CLICK, DOUBLE, HOLD };
  uint8_t pin;
  uint32_t holdMs;
  bool stable = false, lastRaw = false, holdFired = false;
  uint32_t changedAt = 0, pressedAt = 0, lastRelease = 0;
  uint8_t clicks = 0;

  Button(uint8_t p, uint32_t hold) : pin(p), holdMs(hold) {}
  void begin() { pinMode(pin, INPUT_PULLUP); }
  Event poll() {
    uint32_t now = millis();
    bool raw = digitalRead(pin) == LOW;
    if (raw != lastRaw) { lastRaw = raw; changedAt = now; }
    if (now - changedAt > 25 && raw != stable) {
      stable = raw;
      if (stable) { pressedAt = now; holdFired = false; }
      else if (!holdFired && now - pressedAt < 600) { clicks++; lastRelease = now; }
    }
    if (stable && !holdFired && now - pressedAt >= holdMs) {
      holdFired = true;
      clicks = 0;
      return HOLD;
    }
    if (!stable && clicks && now - lastRelease > 300) {
      Event e = clicks >= 2 ? DOUBLE : CLICK;
      clicks = 0;
      return e;
    }
    return NONE;
  }
};
static Button stickBtn(PIN_JOY_SW, PAIR_HOLD_MS);
static Button bootBtn(PIN_BOOT_BTN, SLEEP_HOLD_MS);

// ---------------------------------------------------------------------------
// Joystick
// ---------------------------------------------------------------------------
static int readRaw(uint8_t pin) {
  int sum = 0;
  for (int i = 0; i < 4; ++i) sum += analogRead(pin);
  return sum / 4;
}

static int shapeAxis(int raw, int center) {
  const int margin = 60;  // so full deflection reaches 100 % despite ADC end effects
  int v;
  if (raw >= center) v = (raw - center) * 100 / max(1, 4095 - center - margin);
  else v = (raw - center) * 100 / max(1, center - margin);
  v = constrain(v, -100, 100);
  int a = abs(v);
  if (a <= JOY_DEADZONE) return 0;
  float f = (a - JOY_DEADZONE) / float(100 - JOY_DEADZONE);
  float e = JOY_EXPO / 100.0f;
  f = f * (1 - e) + f * f * f * e;
  int out = (int)lroundf(f * 100);
  return v > 0 ? out : -out;
}

static void calibrate() {
  long sx = 0, sy = 0;
  for (int i = 0; i < 32; ++i) {
    sx += analogRead(PIN_JOY_X);
    sy += analogRead(PIN_JOY_Y);
    delay(2);
  }
  centerX = sx / 32;
  centerY = sy / 32;
  // Stick pushed during power-up: fall back to mid-scale.
  if (abs(centerX - 2048) > 700) centerX = 2048;
  if (abs(centerY - 2048) > 700) centerY = 2048;
  Serial.printf("[connect] stick centre %d / %d\n", centerX, centerY);
}

static void readStick() {
  int ax = shapeAxis(readRaw(PIN_JOY_X), centerX);
  int ay = shapeAxis(readRaw(PIN_JOY_Y), centerY);
#if JOY_SWAP_XY
  int t = ax; ax = ay; ay = t;
#endif
#if JOY_INVERT_X
  ax = -ax;
#endif
#if JOY_INVERT_Y
  ay = -ay;
#endif
  stickX = ax;
  stickY = ay;
  if (ax || ay) lastMoveMs = millis();
}

// ---------------------------------------------------------------------------
// ESP-NOW
// ---------------------------------------------------------------------------
static void addPeer(const uint8_t *mac) {
  if (esp_now_is_peer_exist(mac)) return;
  esp_now_peer_info_t p = {};
  memcpy(p.peer_addr, mac, 6);
  p.channel = 0;  // current channel = LUNE_ESPNOW_CHANNEL
  p.ifidx = WIFI_IF_STA;
  esp_now_add_peer(&p);
}

static void onRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  if (!luneHeaderValid(data, len)) return;
  uint8_t type = ((const LuneHeader *)data)->type;
  if (type == LUNE_PKT_PAIR_ACK && len >= (int)sizeof(LunePairAck) && mode == MODE_PAIRING) {
    portENTER_CRITICAL(&mux);
    memcpy(ackMac, info->src_addr, 6);
    memcpy(ackName, ((const LunePairAck *)data)->name, 12);
    ackName[12] = 0;
    ackPending = true;
    portEXIT_CRITICAL(&mux);
  } else if (type == LUNE_PKT_TELEMETRY && len >= (int)sizeof(LuneTelemetry) && hasRover &&
             memcmp(info->src_addr, roverMac, 6) == 0) {
    portENTER_CRITICAL(&mux);
    memcpy(&telem, data, sizeof(telem));
    telemMs = millis();
    portEXIT_CRITICAL(&mux);
  }
}

static bool linked() {
  uint32_t t = telemMs;
  return t && millis() - t < LINK_LOST_MS;
}

static void sendControl() {
  LuneControl c = {};
  luneFillHeader(c.h, LUNE_PKT_CONTROL, txSeq++);
  c.x = stickX;
  c.y = stickY;
  c.maxSpeed = SPEED_MODES[speedMode];
  c.moodSeq = moodSeq;
  esp_now_send(roverMac, (const uint8_t *)&c, sizeof(c));
}

static void sendPairReq() {
  LunePairReq r = {};
  luneFillHeader(r.h, LUNE_PKT_PAIR_REQ, txSeq++);
  strncpy(r.name, "Connect", sizeof(r.name));
  esp_now_send(BROADCAST, (const uint8_t *)&r, sizeof(r));
}

static void finishPairing() {
  uint8_t mac[6];
  portENTER_CRITICAL(&mux);
  memcpy(mac, ackMac, 6);
  memcpy(roverName, ackName, sizeof(roverName));
  ackPending = false;
  portEXIT_CRITICAL(&mux);
  if (hasRover && memcmp(mac, roverMac, 6) != 0 && esp_now_is_peer_exist(roverMac))
    esp_now_del_peer(roverMac);
  memcpy(roverMac, mac, 6);
  hasRover = true;
  addPeer(roverMac);
  Preferences prefs;
  prefs.begin("connect", false);
  prefs.putBytes("rover", roverMac, 6);
  prefs.putString("name", roverName);
  prefs.end();
  mode = MODE_DRIVE;
  showToast("PAIRED!", 1500);
  Serial.printf("[connect] paired with %02X:%02X:%02X:%02X:%02X:%02X\n", mac[0], mac[1], mac[2],
                mac[3], mac[4], mac[5]);
}

// ---------------------------------------------------------------------------
// Display (own task so I2C transfers never delay the 50 Hz send loop)
// ---------------------------------------------------------------------------
static void drawBars(int x, int y, int8_t rssi, bool ok) {
  int n = !ok ? 0 : rssi > -55 ? 4 : rssi > -67 ? 3 : rssi > -78 ? 2 : 1;
  for (int i = 0; i < 4; ++i) {
    int h = 2 + i * 2;
    if (i < n) oled.drawBox(x + i * 4, y + 8 - h, 3, h);
    else oled.drawFrame(x + i * 4, y + 8 - h, 3, h);
  }
}

static void drawTread(int x, int8_t v) {
  // Vertical bar, centre line at y 40, ±20 px.
  oled.drawFrame(x, 19, 7, 43);
  int h = abs(v) * 20 / 100;
  if (v > 0) oled.drawBox(x + 1, 40 - h, 5, h);
  else if (v < 0) oled.drawBox(x + 1, 41, 5, h);
  oled.drawHLine(x - 1, 40, 9);
}

static void drawDrive(uint32_t now) {
  LuneTelemetry t;
  portENTER_CRITICAL(&mux);
  t = telem;
  portEXIT_CRITICAL(&mux);
  bool ok = linked();

  // Header
  oled.setFont(u8g2_font_6x10_tr);
  oled.drawStr(0, 8, roverName[0] ? roverName : "Lun-E");
  drawBars(112, 0, t.rssi, ok);
  if (!ok && (now / 500) % 2) oled.drawStr(60, 8, "NO LINK");
  oled.drawHLine(0, 11, 128);

  // Stick box
  oled.drawFrame(0, 16, 46, 46);
  oled.drawPixel(23, 39);
  int sx = 23 + stickX * 20 / 100, sy = 39 - stickY * 20 / 100;
  oled.drawDisc(sx, sy, 3);

  // Info column
  char buf[20];
  snprintf(buf, sizeof(buf), "SPD %u%%", SPEED_MODES[speedMode]);
  oled.drawStr(52, 24, buf);
  snprintf(buf, sizeof(buf), "%s", ok && t.mood < LUNE_MOOD_COUNT ? MOOD_NAMES[t.mood] : "-");
  oled.drawStr(52, 40, buf);
  if (ok && t.source == LUNE_SRC_APP) oled.drawStr(52, 60, "APP DRIVES");
  else if (ok && (t.flags & LUNE_FLAG_APP_LINK)) oled.drawStr(52, 60, "+ APP");

  // Applied tread output reported by the rover
  drawTread(110, ok ? t.left : 0);
  drawTread(120, ok ? t.right : 0);
}

static void drawPairing(uint32_t now) {
  oled.setFont(u8g2_font_9x15B_tr);
  oled.drawStr(18, 20, "PAIRING");
  int dots = (now / 300) % 4;
  for (int i = 0; i < dots; ++i) oled.drawDisc(92 + i * 8, 16, 2);
  oled.setFont(u8g2_font_6x10_tr);
  oled.drawStr(4, 40, "Double-click the");
  oled.drawStr(4, 52, "rover's button.");
  oled.drawStr(4, 63, "BOOT = cancel");
}

static void displayTask(void *) {
  TickType_t last = xTaskGetTickCount();
  for (;;) {
    uint32_t now = millis();
    if (mode == MODE_SLEEPING) {
      oled.clearBuffer();
      oled.setFont(u8g2_font_9x15B_tr);
      oled.drawStr(46, 38, "zzz");
      oled.sendBuffer();
      vTaskDelay(pdMS_TO_TICKS(400));
      oled.setPowerSave(1);
      vTaskSuspend(nullptr);
    }
    oled.clearBuffer();
    if (mode == MODE_PAIRING) drawPairing(now);
    else drawDrive(now);

    char tt[20];
    bool show;
    portENTER_CRITICAL(&mux);
    show = (int32_t)(toastUntil - now) > 0;
    if (show) memcpy(tt, toast, sizeof(tt));
    portEXIT_CRITICAL(&mux);
    if (show) {
      oled.setFont(u8g2_font_6x10_tr);
      int w = oled.getStrWidth(tt);
      int x = (128 - w) / 2;
      oled.setDrawColor(0);
      oled.drawBox(x - 4, 24, w + 8, 16);
      oled.setDrawColor(1);
      oled.drawFrame(x - 4, 24, w + 8, 16);
      oled.drawStr(x, 35, tt);
    }
    oled.sendBuffer();
    vTaskDelayUntil(&last, pdMS_TO_TICKS(66));  // ~15 fps
  }
}

// ---------------------------------------------------------------------------
// Sleep
// ---------------------------------------------------------------------------
static void goToSleep() {
  Serial.println("[connect] sleep");
  // Tell the rover to stop: a few neutral packets.
  stickX = 0;
  stickY = 0;
  if (hasRover) for (int i = 0; i < 3; ++i) { sendControl(); delay(10); }
  mode = MODE_SLEEPING;
  if (hasOled) delay(600);  // let the display task show "zzz" and blank
  uint32_t t0 = millis();
  while (digitalRead(PIN_JOY_SW) == LOW && millis() - t0 < 5000) delay(10);
  gpio_pullup_en((gpio_num_t)PIN_JOY_SW);
  gpio_hold_en((gpio_num_t)PIN_JOY_SW);
#if !SOC_GPIO_SUPPORT_HOLD_SINGLE_IO_IN_DSLP
  gpio_deep_sleep_hold_en();
#endif
  esp_deep_sleep_enable_gpio_wakeup(1ULL << PIN_JOY_SW, ESP_GPIO_WAKEUP_GPIO_LOW);
  esp_deep_sleep_start();
}

// ---------------------------------------------------------------------------
void setup() {
  gpio_hold_dis((gpio_num_t)PIN_JOY_SW);
#if !SOC_GPIO_SUPPORT_HOLD_SINGLE_IO_IN_DSLP
  gpio_deep_sleep_hold_dis();
#endif
  Serial.begin(115200);
  stickBtn.begin();
  bootBtn.begin();
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);
  delay(50);
  calibrate();

  Preferences prefs;
  prefs.begin("connect", true);
  hasRover = prefs.getBytes("rover", roverMac, 6) == 6;
  String n = prefs.getString("name", "");
  prefs.end();
  strncpy(roverName, n.c_str(), sizeof(roverName) - 1);

  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
  Wire.beginTransmission(OLED_ADDR);
  hasOled = Wire.endTransmission() == 0;
  if (hasOled) {
    oled.setI2CAddress(OLED_ADDR << 1);
    oled.setBusClock(400000);
    oled.begin();
    oled.setContrast(200);
  }
  Serial.printf("[connect] OLED %s\n", hasOled ? "found" : "not found");

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  WiFi.setSleep(false);  // no BLE here, keep the radio awake for low latency
  esp_wifi_set_channel(LUNE_ESPNOW_CHANNEL, WIFI_SECOND_CHAN_NONE);
  if (esp_now_init() != ESP_OK) Serial.println("[connect] esp_now_init failed");
  esp_now_register_recv_cb(onRecv);
  addPeer(BROADCAST);
  if (hasRover) addPeer(roverMac);

  // Pair on first use, or if the stick is held down while powering up.
  if (!hasRover || digitalRead(PIN_JOY_SW) == LOW) mode = MODE_PAIRING;
  lastMoveMs = millis();

  if (hasOled) xTaskCreate(displayTask, "oled", 4096, nullptr, 1, nullptr);
}

void loop() {
  uint32_t now = millis();
  readStick();

  Button::Event se = stickBtn.poll();
  Button::Event be = bootBtn.poll();

  if (mode == MODE_PAIRING) {
    static uint32_t lastReq = 0;
    if (now - lastReq >= PAIR_REQ_MS) { lastReq = now; sendPairReq(); }
    if (ackPending) finishPairing();
    if (be == Button::CLICK && hasRover) { mode = MODE_DRIVE; showToast("CANCELLED"); }
    if (be == Button::HOLD) goToSleep();
    if (now - lastMoveMs > AUTO_SLEEP_MS) goToSleep();
    delay(5);
    return;
  }

  // ---- Drive mode ----
  switch (se) {
    case Button::DOUBLE:
      speedMode = (speedMode + 1) % sizeof(SPEED_MODES);
      {
        char b[16];
        snprintf(b, sizeof(b), "SPEED %u%%", SPEED_MODES[speedMode]);
        showToast(b);
      }
      break;
    case Button::HOLD: mode = MODE_PAIRING; break;
    default: break;
  }
  if (se != Button::NONE) lastMoveMs = now;
  if (be == Button::CLICK || be == Button::DOUBLE) { moodSeq++; lastMoveMs = now; }
  if (be == Button::HOLD) goToSleep();

  static uint32_t lastSend = 0;
  bool active = stickX || stickY;
  if (hasRover && now - lastSend >= (uint32_t)(active ? SEND_ACTIVE_MS : SEND_IDLE_MS)) {
    lastSend = now;
    sendControl();
  }

  if (now - lastMoveMs > AUTO_SLEEP_MS) goToSleep();
  delay(2);
}
