# Lun-E firmware

Lun-E RC can be driven from two places:

- **Connect**, the thumbstick controller, over ESP-NOW. It has to be paired first.
- **The phone app**, a web page that talks to the rover over Bluetooth LE.

Both can be on at the same time. Whoever moves their stick first takes control. The other one can take over once the first stick has been centred for 0.3 s. If the driving side goes quiet for 0.3 s, the motors stop.

```
common/lune_protocol.h   packet formats + BLE UUIDs (shared by both firmwares and the app)
rover/                   Lun-E RC firmware   (PlatformIO, ESP32-C3-MINI-1-H4)
connect/                 Connect firmware    (PlatformIO, Glyph C3)
app/index.html           phone app (Web Bluetooth), a single file
```

## Build and flash

Both projects use **pioarduino**, the community fork that brings Arduino-ESP32 core 3.x to PlatformIO. The URL is already in each `platformio.ini`. The stock PlatformIO `espressif32` platform is still on core 2.x and will not build these projects.

```
cd rover   && pio run -t upload && pio device monitor
cd connect && pio run -t upload && pio device monitor
```

- **Rover, first flash of a blank board:** short JP1 (BOOT, GPIO9) while you plug in USB. Flash, then remove JP1. After that, flashing over USB works directly.
- **Connect:** if the upload can't connect, hold BOOT while you plug it in.
- The libraries download automatically: NimBLE-Arduino 2.x and U8g2.

## Before first drive

Check these on the bench with the treads off the ground.

1. **Motor direction** (`rover/src/config.h`). Push the stick forward. Both treads should drive forward. If they don't, fix it with `MOTOR_A_IS_LEFT`, `MOTOR_LEFT_INVERT` and `MOTOR_RIGHT_INVERT`. No rewiring needed.
2. **Connect joystick pins** (`connect/src/config.h`). The defaults are VRx = GPIO0, VRy = GPIO1, SW = GPIO3, and the OLED on SDA 4 / SCL 5 (the Glyph's I2C). Change them to match your wiring. The X and Y pins must be GPIO0–4 (ADC1). SW must be GPIO0–5 so it can wake the controller. Then use `JOY_SWAP_XY` and the `JOY_INVERT_*` flags until the screen's stick dot moves the same way as your thumb.
3. **OLED orientation.** If the eyes show upside down, set `OLED_ROTATION 2`.
4. **N20 dead band.** If small stick moves hum without turning, raise `MOTOR_MIN_DUTY` (default 28 %).

## Pairing Connect with the rover

1. A new rover shows **PAIR ME** and accepts the first Connect that asks. To re-pair later, **double-click the rover's button**. That opens a 30 s pairing window. The app's Setup → *Pair a Connect* does the same.
2. On Connect, pairing starts by itself on first use. Otherwise, hold the stick button for 3 s, or hold it while powering on.
3. Both screens show **PAIRED!** Both boards remember the pairing across power-off.

## Controls

| | Rover button (GPIO5) | Connect | App |
|---|---|---|---|
| Headlights | click | stick click | Headlights button / `L` key |
| Eye expression | — | BOOT click (next) | emoji row |
| Speed limit | — | stick double-click (40 / 70 / 100 %) | slider |
| Pair | double-click | hold stick 3 s | Setup → Pair a Connect |
| Sleep | hold 1.5 s and release | hold BOOT 1.5 s | Setup → Sleep (tap twice) |
| Wake | press button | stick click | — |
| Steering trim | — | — | Setup → trim slider (saved on the rover) |

Auto-sleep:

- **Rover:** after 5 min with no Connect, no phone connected and no driving.
- **Connect:** after 3 min without touching the stick.

## Phone app

Web Bluetooth only works over **https**. Two ways to run the app:

- **Hosted:** open **https://whybit.in/drive/** in **Chrome on Android**. Desktop Chrome and Edge work too, with W A S D / arrow keys. `app/index.html` here is the same app as a standalone file.
- **Test locally:** run `python3 -m http.server` in `app/` and open `http://localhost:8000`. Browsers allow Bluetooth on localhost.

On **iPhone**, Safari has no Web Bluetooth. Open the page in the free **Bluefy** browser instead.

The rover advertises as `Lun-E RC-XXXX`, where XXXX is the end of its MAC address.

## Protocol summary

ESP-NOW runs on Wi-Fi channel 1. Neither board joins a Wi-Fi network. Every packet starts with `'L','E', version, type, seq`.

| Packet | Direction | Rate | Payload |
|---|---|---|---|
| PAIR_REQ | Connect → broadcast | 3 Hz while pairing | name |
| PAIR_ACK | rover → Connect | once | name |
| CONTROL | Connect → rover | 50 Hz moving, 10 Hz centred | x, y, maxSpeed, lightsSeq, moodSeq |
| TELEMETRY | rover → Connect | 5 Hz | flags, source, mood, L/R output, RSSI |

Button presses travel as counters (`lightsSeq`, `moodSeq`). A lost packet can't drop or repeat a press.

BLE service `6e4c0001-…`:

- **DRIVE**: write without response. `int8 x, int8 y, uint8 maxSpeed`, sent at 20 Hz.
- **CMD**: write. `cmd, arg` — lights, mood, trim, pair, sleep.
- **STATUS**: notify at 5 Hz. 10 bytes, laid out in `LuneBleStatus`.
