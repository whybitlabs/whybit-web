#!/usr/bin/env bash
# Build Lun-E RC, Lun-E Glyph and Connect, and copy the flashable parts into the
# website so https://whybit.in/flash/ serves the newest firmware.
#
#   tools/publish-firmware.sh                 # site at ~/whybit-web
#   tools/publish-firmware.sh /path/to/site   # somewhere else
#   VERSION=1.2.0 tools/publish-firmware.sh   # name the version yourself
#
# Then commit + push whybit-web (flash/firmware/**) as usual.
#
# Each board gets four parts at their normal offsets — NOT the merged
# firmware.factory.bin, because that one fills the NVS area with 0xFF and would
# wipe the rover's number, pairing, motor direction and trim on every flash.
#   bootloader.bin  0x0      (ESP32-C3 / ESP32-S3)
#   partitions.bin  0x8000
#   boot_app0.bin   0xE000   (otadata: boot from app0)
#   firmware.bin    0x10000
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SITE="${1:-$HOME/whybit-web}"
OUT="$SITE/flash/firmware"
VERSION="${VERSION:-$(date +%Y.%m.%d-%H%M)}"

command -v pio >/dev/null || { echo "pio (PlatformIO) not found on PATH" >&2; exit 1; }
[ -d "$SITE" ] || { echo "website folder not found: $SITE" >&2; exit 1; }

publish() {  # project env slug "Name" chipFamily
  local proj="$1" env="$2" slug="$3" name="$4" chip="$5"
  echo "== $name ($proj, env $env)"
  (cd "$ROOT/$proj" && pio run -e "$env")
  local build="$ROOT/$proj/.pio/build/$env" dest="$OUT/$slug"

  # boot_app0.bin ships with the Arduino-ESP32 framework PlatformIO downloaded.
  local boot_app0
  boot_app0="$(find "$HOME/.platformio/packages" -path '*framework-arduinoespressif32*' \
               -name boot_app0.bin 2>/dev/null | head -n 1)"
  [ -n "$boot_app0" ] || { echo "boot_app0.bin not found under ~/.platformio/packages" >&2; exit 1; }

  mkdir -p "$dest"
  cp "$build/bootloader.bin" "$build/partitions.bin" "$build/firmware.bin" "$dest/"
  cp "$boot_app0" "$dest/boot_app0.bin"

  cat > "$dest/manifest.json" <<JSON
{
  "name": "$name",
  "version": "$VERSION",
  "new_install_prompt_erase": true,
  "new_install_improv_wait_time": 0,
  "builds": [
    {
      "chipFamily": "$chip",
      "parts": [
        { "path": "bootloader.bin", "offset": 0 },
        { "path": "partitions.bin", "offset": 32768 },
        { "path": "boot_app0.bin", "offset": 57344 },
        { "path": "firmware.bin", "offset": 65536 }
      ]
    }
  ]
}
JSON
  echo "   -> $dest ($(du -h "$dest/firmware.bin" | cut -f1) firmware, v$VERSION)"
}

publish rover   lune-rc    lun-e-rc    "Lun-E RC"    "ESP32-C3"
publish glyph   lune-glyph lun-e-glyph "Lun-E Glyph" "ESP32-S3"
publish connect connect    connect     "Connect"     "ESP32-C3"

echo
echo "Done: $OUT  (version $VERSION)"
echo "Commit and push whybit-web to put it on https://whybit.in/flash/"
