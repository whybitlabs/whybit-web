#include "eyes.h"
#include <U8g2lib.h>
#include <Wire.h>
#include "config.h"
#include "lune_protocol.h"

namespace {
#if OLED_ROTATION == 2
#define U8_ROT U8G2_R2
#else
#define U8_ROT U8G2_R0
#endif
U8G2_SSD1306_128X64_NONAME_F_HW_I2C oled(U8_ROT, U8X8_PIN_NONE, PIN_I2C_SCL, PIN_I2C_SDA);

bool hasOled = false;
TaskHandle_t task = nullptr;
portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;

// Shared state (written by the main loop, read by the eye task)
volatile uint8_t curMood = LUNE_MOOD_NORMAL;
volatile int lookTX = 0, lookTY = 0;
volatile bool lookActive = false;
char caption[16] = "";
uint32_t captionUntil = 0;
volatile bool wantShutdown = false;
volatile bool isShutDown = false;

// Animation state (eye task only)
float lookX = 0, lookY = 0;          // smoothed, -1..1
float wanderX = 0, wanderY = 0;
uint32_t nextWander = 0, nextBlink = 0, blinkStart = 0;
bool blinking = false;
float openness = 1.0f;               // 1 open, 0 closed

const int EYE_W = 36, EYE_H = 36, EYE_R = 9, EYE_GAP = 22;
const int CX = 64, CY = 30;

// Draw one eye at centre (cx, cy). side: -1 left eye, +1 right eye.
void drawEye(int cx, int cy, int side, uint8_t mood, float open) {
  int w = EYE_W, h = EYE_H, r = EYE_R;
  if (mood == LUNE_MOOD_SURPRISED) { w += 6; h += 8; r += 3; }
  if (mood == LUNE_MOOD_SLEEPY) open *= 0.45f;
  int hh = max(2, (int)(h * open));
  int x0 = cx - w / 2, y0 = cy - hh / 2;
  if (mood == LUNE_MOOD_SLEEPY) y0 = cy + h / 2 - hh - 2;  // droop: keep bottom edge
  int rr = min(r, (hh - 1) / 2);
  oled.setDrawColor(1);
  if (rr >= 1) oled.drawRBox(x0, y0, w, hh, rr);
  else oled.drawBox(x0, y0, w, hh);

  // Lids are drawn in black on top of the eye.
  oled.setDrawColor(0);
  int x1 = x0 + w - 1;
  int lid = hh / 2;
  switch (mood) {
    case LUNE_MOOD_HAPPY:
      // Bottom cut by a disc -> cheerful "^ ^" arcs.
      oled.drawDisc(cx, y0 + hh + w * 0.42f, w * 0.72f);
      break;
    case LUNE_MOOD_SAD:  // outer corner droops
      if (side < 0) oled.drawTriangle(x0 - 1, y0 - 1, x1 + 1, y0 - 1, x0 - 1, y0 + lid);
      else          oled.drawTriangle(x0 - 1, y0 - 1, x1 + 1, y0 - 1, x1 + 1, y0 + lid);
      break;
    case LUNE_MOOD_ANGRY:  // inner corner pushed down
      if (side < 0) oled.drawTriangle(x0 - 1, y0 - 1, x1 + 1, y0 - 1, x1 + 1, y0 + lid);
      else          oled.drawTriangle(x0 - 1, y0 - 1, x1 + 1, y0 - 1, x0 - 1, y0 + lid);
      break;
    default:
      break;
  }
  oled.setDrawColor(1);
}

void renderFrame(uint32_t now) {
  // --- blink ---------------------------------------------------------------
  if (!blinking && now >= nextBlink) { blinking = true; blinkStart = now; }
  if (blinking) {
    uint32_t t = now - blinkStart;  // 0..180 ms: close 70, hold 30, open 80
    if (t < 70) openness = 1.0f - t / 70.0f;
    else if (t < 100) openness = 0.0f;
    else if (t < 180) openness = (t - 100) / 80.0f;
    else {
      openness = 1.0f;
      blinking = false;
      nextBlink = now + 1800 + (esp_random() % 4200);
      if ((esp_random() % 6) == 0) nextBlink = now + 250;  // occasional double blink
    }
  }

  // --- gaze ----------------------------------------------------------------
  float tx, ty;
  if (lookActive) {
    tx = lookTX / 100.0f;
    ty = -lookTY / 250.0f;  // throttle forward -> look slightly up
  } else {
    if (now >= nextWander) {
      wanderX = ((int)(esp_random() % 201) - 100) / 140.0f;
      wanderY = ((int)(esp_random() % 201) - 100) / 300.0f;
      if ((esp_random() % 3) == 0) wanderX = wanderY = 0;
      nextWander = now + 1200 + (esp_random() % 2800);
    }
    tx = wanderX;
    ty = wanderY;
  }
  float k = lookActive ? 0.35f : 0.18f;
  lookX += (tx - lookX) * k;
  lookY += (ty - lookY) * k;

  int dx = (int)(lookX * 12), dy = (int)(lookY * 8);
  uint8_t mood = curMood;

  oled.clearBuffer();
  drawEye(CX - (EYE_W + EYE_GAP) / 2 + dx, CY + dy, -1, mood, openness);
  drawEye(CX + (EYE_W + EYE_GAP) / 2 + dx, CY + dy, +1, mood, openness);

  char cap[16];
  bool showCap;
  portENTER_CRITICAL(&mux);
  showCap = (int32_t)(captionUntil - now) > 0 && caption[0];
  if (showCap) memcpy(cap, caption, sizeof(cap));
  portEXIT_CRITICAL(&mux);
  if (showCap) {
    oled.setFont(u8g2_font_6x10_tr);
    int w = oled.getStrWidth(cap);
    int x = (128 - w) / 2;
    oled.setDrawColor(0);
    oled.drawBox(x - 3, 53, w + 6, 11);
    oled.setDrawColor(1);
    oled.drawStr(x, 62, cap);
  }
  oled.sendBuffer();
}

void eyeTask(void *) {
  const TickType_t period = pdMS_TO_TICKS(1000 / EYES_FPS);
  TickType_t last = xTaskGetTickCount();
  nextBlink = millis() + 1500;
  for (;;) {
    if (wantShutdown) {
      // Slow close, then panel off.
      for (int i = 10; i >= 0; --i) {
        openness = i / 10.0f;
        oled.clearBuffer();
        drawEye(CX - (EYE_W + EYE_GAP) / 2, CY, -1, LUNE_MOOD_NORMAL, openness);
        drawEye(CX + (EYE_W + EYE_GAP) / 2, CY, +1, LUNE_MOOD_NORMAL, openness);
        oled.sendBuffer();
        vTaskDelay(pdMS_TO_TICKS(30));
      }
      oled.clearBuffer();
      oled.sendBuffer();
      oled.setPowerSave(1);
      isShutDown = true;
      vTaskSuspend(nullptr);
    }
    renderFrame(millis());
    vTaskDelayUntil(&last, period);
  }
}
}  // namespace

namespace Eyes {

bool begin() {
  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
  Wire.beginTransmission(OLED_ADDR);
  hasOled = (Wire.endTransmission() == 0);
  if (!hasOled) return false;
  oled.setI2CAddress(OLED_ADDR << 1);
  oled.setBusClock(400000);
  oled.begin();
  oled.setPowerSave(0);
  oled.setContrast(200);
  xTaskCreate(eyeTask, "eyes", 4096, nullptr, 1, &task);
  return true;
}

bool present() { return hasOled; }

void setMood(uint8_t m) {
  if (m < LUNE_MOOD_COUNT) curMood = m;
}
uint8_t mood() { return curMood; }
void nextMood() { curMood = (curMood + 1) % LUNE_MOOD_COUNT; }

void lookAt(int x, int y, bool active) {
  lookTX = x;
  lookTY = y;
  lookActive = active;
}

void say(const char *text, uint32_t ms) {
  portENTER_CRITICAL(&mux);
  strncpy(caption, text, sizeof(caption) - 1);
  caption[sizeof(caption) - 1] = 0;
  captionUntil = millis() + ms;
  portEXIT_CRITICAL(&mux);
}

void shutdown() {
  if (!hasOled || isShutDown) return;
  wantShutdown = true;
  uint32_t t0 = millis();
  while (!isShutDown && millis() - t0 < 800) delay(10);
}

}  // namespace Eyes
