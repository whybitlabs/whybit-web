// Lun-E RC — board pins and tuning. Pins match schematic v1.5.
#pragma once
#include <Arduino.h>

// ---- Pins (ESP32-C3-MINI-1) ------------------------------------------------
#define PIN_AIN1        4    // DRV8833 motor A
#define PIN_AIN2        0
#define PIN_BIN1        6    // DRV8833 motor B
#define PIN_BIN2        7
#define PIN_MOT_SLEEP   10   // DRV8833 nSLEEP, HIGH = motors enabled
#define PIN_LIGHT_L     1    // left headlight D2, LOW = on
#define PIN_LIGHT_R     20   // right headlight D3, LOW = on
#define PIN_BUTTON      5    // user button, active LOW, deep-sleep wake
#define PIN_I2C_SDA     8    // OLED header J5
#define PIN_I2C_SCL     2
#define OLED_ADDR       0x3C

// ---- Motor wiring --------------------------------------------------------
// Which DRV8833 channel drives which tread, and whether it spins backwards.
// Test once on the bench: push the stick forward — both treads must drive
// forward. Fix with these four flags, no rewiring needed.
// Bench-tested on Lun-E RC (2026-10-26): channel B drives the left tread and
// spins it backwards; channel A drives the right tread the right way round.
#define MOTOR_A_IS_LEFT   0
#define MOTOR_LEFT_INVERT  1
#define MOTOR_RIGHT_INVERT 0

// ---- Motor tuning ----------------------------------------------------------
#define MOTOR_PWM_FREQ     20000  // Hz, above hearing
#define MOTOR_PWM_BITS     10
#define MOTOR_SLOW_DECAY   1      // 1 = brake between pulses (better low-speed torque)
#define MOTOR_MIN_DUTY     28     // % — N20 dead band; smallest non-zero command maps here
#define MOTOR_SLEW_PER_S   400    // % per second — limits current spikes on the 300 mAh cell
#define MOTOR_IDLE_SLEEP_MS 1500  // drop nSLEEP after this long at zero output
#define TURN_GAIN          70     // % — how strongly the stick's X axis turns
#define INPUT_DEADZONE     6      // % — stick values below this are treated as 0

// ---- Control / safety ------------------------------------------------------
#define FAILSAFE_MS        300    // stop if the active source goes quiet this long
#define HANDOVER_IDLE_MS   300    // other source may take over after the owner is neutral this long
#define CONNECT_LINK_MS    1000   // Connect counts as "linked" if heard within this
#define PAIRING_WINDOW_MS  30000
#define TELEMETRY_MS       200    // rover -> Connect / app status rate

// ---- Power -----------------------------------------------------------------
#define AUTO_SLEEP_MS      (5UL * 60UL * 1000UL)  // idle with no Connect and no phone
#define BUTTON_SLEEP_MS    1500   // hold button this long, release -> deep sleep

// ---- Display ---------------------------------------------------------------
// 0 = normal, 2 = rotated 180° (if the eyes appear upside down).
#define OLED_ROTATION      0
#define EYES_FPS           30
